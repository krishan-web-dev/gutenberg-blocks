import { registerBlockType } from '@wordpress/blocks';
import '../blocks/hero-widget/index';
import '../blocks/featured-products/index';
